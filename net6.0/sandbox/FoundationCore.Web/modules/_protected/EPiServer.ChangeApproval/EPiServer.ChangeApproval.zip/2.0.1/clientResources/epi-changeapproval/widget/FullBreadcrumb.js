define([
    "dojo/_base/declare",
    "epi-cms/widget/Breadcrumb"
], function (declare, Breadcrumb) {

    return declare([Breadcrumb], {
        // summary:
        //      Breadcrumb that always display full path
        // tags:
        //      internal

        _getTotalVisibleItemsSize: function () {
            return 0;
        },

        /*eslint-disable */
        _ellipsisize: function (startIndex, availableWidth) {
            /*eslint-enable */
            return;
        }
    });
});

