define([
    "epi-changeapproval/ChangeApprovalModule",
    "epi-changeapproval/widget/ApprovalCommandView",
    "epi-changeapproval/widget/ApprovalCommandDetailsView",
    "epi-changeapproval/widget/ExpirationChangeDetailsView",
    "epi-changeapproval/widget/MovingContentCommandView"
], 1);
