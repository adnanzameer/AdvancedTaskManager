define([
// dojo
    "dojo/date/locale",
    "dojo/dom-construct",
    "dojo/dom-class",
    "dojo/dom-style",
    "dojo/when",
    "dojo/_base/lang",

// epi
    "epi/datetime",
    "epi/shell/dgrid/Formatter",
    "epi-cms/core/ContentReference",
    "epi-changeapproval/widget/FullBreadcrumb",
    "epi/dependency",

// dijit
    "dijit/form/CheckBox",

// epi-changeapproval
    "epi-changeapproval/ModuleSettings"
],
function (
// dojo
    locale,
    domConstruct,
    domClass,
    domStyle,
    when,
    lang,

// epi
    epiDateTime,
    Formatter,
    ContentReference,
    Breadcrumb,
    dependency,
// dijit
    CheckBox,

// epi-changeapproval
    ModuleSettings
) {

    // module:
    //      epi-forms/dgrid/Formatters
    // summary:
    //      Register custom formatters to dgrid that used in EPiServer Forms addon.
    //      Formatters:
    //          dateTimeFormatter
    //          embededLinksFormatter
    //          encodeAndEllipsisFormatter
    //          removeNullValueFormatter
    // tags:
    //      internal

    var module = {

        isRecordFieldValue: function (/*Object*/value) { // check whether a string contains a record separator.
            if (value.indexOf(ModuleSettings.recordSeparator) >= 0) {
                return true;
            }

            return false;
        },

        dateTimeFormatter: function (/*Object*/value, node) {
            // summary:
            //      Returns formate of DateTime as "yyyy-MM-dd HH:mm:ss".
            // tags:
            //      public

            node.innerHTML = epiDateTime.toUserFriendlyHtml(value);
        },

        removeNullValueFormatter: function (/*Object*/value) {
            // summary:
            //      Returns empty string instead of null to display on grid.
            // tags:
            //      public

            return value == null ? "" : value;
        },

        recordFieldFormatter: function (/*Boolean*/ value,node) {
            // summary:
            //      render a record including items separated by a recordSeparator.
            // tags:
            //      public
            if (!value) {
                return;
            }

            var content = value.split(ModuleSettings.recordSeparator).join("</br>");
            node.innerHTML = content;

            return content;
        },

        contentItem: function (value, node) {
            // summary:
            //      receive the data from grids and then choose the suitable function to render it to browser.
            // tags:
            //      public

            value = this.removeNullValueFormatter(value);

            if (this.isRecordFieldValue(value)) {
                return this.recordFieldFormatter(value, node);
            }

            node.innerHTML = value;
            return value;
        },

        breadcrumbFormatter: function (value, node, options, missingText) {
            if (!value) {
                if (missingText) {
                    node.innerText = missingText;
                }
                return;
            }
            var registry = dependency.resolve("epi.storeregistry");
            this.store = this.store || registry.get("epi.cms.content.light");
            var currentContentReference = new ContentReference(value),
                contentLinkWithoutWorkId = currentContentReference.createVersionUnspecificReference();

            when(this.store.get(contentLinkWithoutWorkId.toString()), lang.hitch(this, function (currentContent) {
                var breadCrumb = null;

                breadCrumb = new Breadcrumb(options);
                breadCrumb._destroyOnRemove = true;
                breadCrumb.set("contentLink", contentLinkWithoutWorkId);
                domConstruct.place(breadCrumb.domNode, node, "only");
                node.widget = breadCrumb;

                // if the current content is content assets folder (e.g "For This Block / For This Folder")
                // we get Breadcrumb for its owner and merge it into template
                if (currentContent.ownerContentLink) {
                    // for checking the access right of content's parent. 
                    // If the current user does not have read privilege on the parent, then, do concanate the path of parent to that of current content.

                    when(this.store.get(currentContent.ownerContentLink), lang.hitch(this, function (parent) {
                        if (parent.name) {
                            var parentBreadCrumb;
                            var ownerContentReference = new ContentReference(currentContent.ownerContentLink);
                            breadCrumb.own(parentBreadCrumb = new Breadcrumb(options));
                            parentBreadCrumb._destroyOnRemove = true;
                            parentBreadCrumb.set("contentLink", ownerContentReference.createVersionUnspecificReference());
                            domConstruct.place(parentBreadCrumb.domNode, node, "first");
                        }
                    }));
                }

                domClass.add(node, "epi-changeapproval-breadcrumb-wrapper");
            }));
        }
    };

    Formatter.addFormatter("dateTimeFormatter", module.dateTimeFormatter);
    Formatter.addFormatter("removeNullValueFormatter", module.removeNullValueFormatter);
    Formatter.addFormatter("recordFieldFormatter", module.recordFieldFormatter);
    Formatter.addFormatter("contentItem", module.contentItem);
    Formatter.addFormatter("breadcrumbFormatter", module.breadcrumbFormatter);

    return module;
});
