define([
    "dojo/Stateful",
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/when",
    "dijit/Destroyable",
    "epi",
    "epi/datetime",
    "epi/dependency",
    "epi/username",
    "epi/shell/command/_CommandConsumerMixin",
    "epi/shell/command/_GlobalCommandProviderMixin",
    "epi-changeapproval/ModuleSettings",
    "epi/i18n!epi/cms/nls/episerver.changeapproval.approvalcommandview.approvalmenu"
],

function (
    Stateful,
    declare,
    lang,
    when,
    Destroyable,
    epi,
    epiDate,
    dependency,
    username,
    _CommandConsumerMixin,
    _GlobalCommandProviderMixin,
    ModuleSettings,
    res
    ) {

    return declare([Stateful, _CommandConsumerMixin, _GlobalCommandProviderMixin, Destroyable], {
        // tags:
        //      internal

        commandKey: "epi-changeapproval.changeapprovalmenu",

        // Methods
        // ---------------------------------------------------------------------
        postscript: function () {
            this.inherited(arguments);

            this.res = this.res || res;
            this.approvalService = this.approvalService || dependency.resolve("epi-changeapproval.changeapprovalservice");

            this.initializeCommandProviders();
        },

        _dataModelSetter: function (dataModel) {
            this.dataModel = dataModel;
            this.updateCommandModel(dataModel);
            this.onDataModelChange();
        },

        onDataModelChange: function () {

            // Update commands
            this._updateCommands();

            // Update other properties
            // -----------------------------------------------------------------------------

            // Set menu sections and texts to defaults before calling specific setters (e.g. _setApprovalInfo etc).
            this.set("topInfoSectionVisible", this._getTopInfoSectionVisible(this.dataModel));
            this.set("bottomInfoSectionVisible", this._getBottomInfoSectionVisible());

            // Clear addtional info
            this.set("additionalInfoSectionVisible", false);
            this.set("additionalInfoText", "");

            if (this._shouldShowApprovalInfo(this.dataModel)) {
                this._setApprovalInfo(this.dataModel);
            } else {
                this._setLastChangeStatus(this.dataModel);
            }
        },

        _isOpenSetter: function (isOpen) {
            this.isOpen = isOpen;
            if (isOpen) {
                if (this._shouldShowApprovalInfo(this.dataModel)) {
                    this._setApprovalInfo(this.dataModel);
                } else {
                    this._setLastChangeStatus(this.dataModel);
                }
            }
        },

        _getTopInfoSectionVisible: function () {
            return true;
        },

        _getBottomInfoSectionVisible: function () {
            return this.getCommands().some(function (command) {
                // If the visible command is the main command then it's not in the bottom info section.
                return command.isAvailable && command !== this.mainButtonCommand;
            }.bind(this));
        },

        _getPublishInfoSectionVisible: function () {
            return true;
        },

        _shouldShowApprovalInfo: function (approvalCommandModel) {
            // summary:
            //      Indicates if the command is in awaiting approval state
            // returns:
            //      true/false
            // tags:
            //      private

            var awaitingApproval = approvalCommandModel.status === ModuleSettings.approvalStatus.PENDING;
            return awaitingApproval;
        },


        _setApprovalInfo: function (approvalCommandModel) {
            // summary:
            //      Retrieve and renders the approval information if found.
            // approvalCommandModel:
            //      The command data object
            // tags:
            //      private

            return this.approvalService.getApproval(approvalCommandModel.appliedOnContent).then(lang.hitch(this, function (approval) {
                // No approval found.
                if (!approval) {
                    // If the command is in an AwaitingApproval state, when there's no approval, the command is stuck in

                    if (this.dataModel.status === ModuleSettings.approvalStatus.PENDING) {
                        this._setAbortInfo(approvalCommandModel);
                    }

                    return null;
                }

                var heading = lang.replace(this.res.approvalinfo.timepassed, {
                    timepassed: epiDate.timePassed(new Date(approval.startDate))
                });

                var stepInfo = " <br /> " + lang.replace(this.res.approvalinfo.stepinfo, {
                    activeStepIndex: approval.activeStepIndex + 1,
                    totalsteps: approval.totalSteps
                });

                // render the top heading
                var topInfoSection = heading + (approval.status === 0 ? stepInfo : "");
                this.set("topInfoSectionVisible", true);
                this.set("lastChangeStatus", topInfoSection);

                var requestedBy = lang.replace(this.res.approvalinfo.requestedby, {
                    username: this._getFriendlyUsername(approval.startedBy, true),
                    time: epiDate.toUserFriendlyHtml(approval.startDate)
                });

                // render who requested/started the approval
                this.set("additionalInfoSectionVisible", true);
                this.set("additionalInfoText", requestedBy);

                // command data is not valid
                if (!approvalCommandModel.isCommandDataValid) {
                    this._setInValidCommandDataInfo();
                }

                return approval;
            })).otherwise(function () {
                return null;
            });
        },

        _setInValidCommandDataInfo: function () {
            // render error message
            this.set("additionalInfoText", this.res.approvalinfo.invalidcommanddata);
        },

        _setAbortInfo: function (approval) {
            // summary:
            //      Renders abort information for command that's stuck in AwaitingApproval.
            // approvalCommandModel:
            //      The command data object
            // tags:
            //      private

            // render the top heading
            this.set("topInfoSectionVisible", true);
            this._setLastChangeStatus(approval);

            // render who requested/started the approval
            this.set("additionalInfoSectionVisible", true);
            // render error message
            this.set("additionalInfoText", this.res.approvalinfo.approvalmissing);
        },

        _setLastChangeStatus: function (approvalCommandModel) {

            var  lastChangeStatus;

            lastChangeStatus =  this._getTemplatedText(this.res.lastchangestatus, approvalCommandModel.changedBy, approvalCommandModel.saved);

            if (approvalCommandModel.status === ModuleSettings.approvalStatus.ACCEPTED) {
                lastChangeStatus = this._getTemplatedText(this.res.acceptedapproval, approvalCommandModel.changedBy, approvalCommandModel.saved);
            }

            if (approvalCommandModel.status === ModuleSettings.approvalStatus.DECLINED) {
                lastChangeStatus = this._getTemplatedText(this.res.rejectedapproval, approvalCommandModel.changedBy, approvalCommandModel.saved);
            }

            when(lastChangeStatus, lang.hitch(this, "set", "lastChangeStatus"));
        },

        _updateCommands: function () {
            this._calculateMainButtonCommand();

            this.set("commands", this.getCommands());
        },

        _calculateMainButtonCommand: function () {
            var commands = this.getCommands(),
                mainCommand = null;

            commands.forEach(function (command) {
                if (command.canExecute &&
                    command.options && command.options.isMain && command.options.priority && (!mainCommand || mainCommand.options.priority < command.options.priority)) {

                    mainCommand = command;
                }
            });

            this.set("mainButtonCommand", mainCommand);
            this.set("mainButtonSectionVisible", mainCommand !== null);
        },

        _getTemplatedText: function (template, username, datetime, capitalizeUsername) {
            // summary:
            //      Return text represent last update time
            // tags:
            //      private

            var date = new Date(datetime);

            return lang.replace(template, {
                username: this._getFriendlyUsername(username, capitalizeUsername),
                time: epiDate.toUserFriendlyHtml(date),
                timepassed: epiDate.timePassed(date)
            });
        },

        _getFriendlyUsername: function (name, capitalizeUsername) {
            // summary:
            //      Get friendly username: if the username to be displayed is the same
            //      as the current username, this will returns "you"
            // name:
            //      the username to be displayed
            // capitalizeUsername:
            //      If the first character should always be displayed with upper case.
            // tags:
            //      private

            return username.toUserFriendlyHtml(name, null, capitalizeUsername);
        }
    });
});
