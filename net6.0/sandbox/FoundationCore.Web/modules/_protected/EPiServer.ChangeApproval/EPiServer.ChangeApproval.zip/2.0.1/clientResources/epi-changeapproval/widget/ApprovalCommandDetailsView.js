define([
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/when",
    "dojo/Deferred",
    "dojo/aspect",

// dijit
    "dijit/_TemplatedMixin",
    "dijit/_WidgetsInTemplateMixin",
    "dijit/_Widget",

//dgrid
    "dgrid/Keyboard",
    "dgrid/OnDemandGrid",
    "dgrid/Selection",
    "dgrid/extensions/ColumnResizer",

// epi
    "epi/dependency",

//epi-changeapproval
    "epi-changeapproval/widget/CommandQueryGrid",
    "epi-changeapproval/widget/dgrid/Formatter",

// resources
    "epi/i18n!epi/cms/nls/episerver.changeapproval"
],
function (
    declare,
    lang,
    when,
    Deferred,
    aspect,

// dijit
    _TemplatedMixin,
    _WidgetsInTemplateMixin,
    _Widget,

// dgrid
    Keyboard,
    OnDemandGrid,
    Selection,
    ColumnResizer,

// epi
    dependency,

// epi-changeapproval
    CommandQueryGrid,
    formatters,

// resources
    res
 ) {

    return declare([_Widget, _TemplatedMixin, _WidgetsInTemplateMixin], {
        // tags:
        //		internal

        res: res,

        storeKeyName: "epi-changeapproval.commanddetaildata",

        templateString: "<div><div data-dojo-attach-point=\"contentNode\"></div></div>",

        _gridClass: declare([OnDemandGrid, Selection, ColumnResizer, Keyboard]),

        _grid: null,

        _gridDefer: null,

        defaultGridMixin: null, // the default grid settings

        postMixInProperties: function () {
            // summary:
            //		Called after constructor parameters have been mixed-in; sets default values for parameters that have not been initialized.
            // tags:
            //		internal
            this.inherited(arguments);

            this._gridDefer = new Deferred();

            this.defaultGridMixin = {
                className: "epi-grid-height--auto epi-changeapproval-grid-detail ",
                minWidth: 300
            };

            if (!this.store && this.storeKeyName) {
                var registry = dependency.resolve("epi.storeregistry");
                this.store = registry.get(this.storeKeyName);
            }
        },

        buildRendering: function () {
            // summary:
            //      Setup the grid
            // tags:
            //      private

            this.inherited(arguments);

            var gridSettings = this._getGridSettings();
            this._grid = new this._gridClass(gridSettings, this.contentNode, "last");
            var self = this;
            // advice for cleaning up widgets
            aspect.before(self._grid, "removeRow", function (rowElement) {
                Object.values(self._grid.columns).forEach(function (column) {
                    var cellElement = self._grid.cell(rowElement, column.id).element,
                        widget = (cellElement.contents || cellElement).widget;
                    if (widget) {
                        widget.destroyRecursive();
                    }
                });
            });
            this._gridDefer.resolve(this._grid);
        },

        _getGridSettings: function () {
            // summary:
            //		get the settings for the grid
            // tags:
            //      protected

            return lang.mixin({
                columns: {
                    name: {
                        label: res.gridcommanddetail.column.name,
                        className: "epi-grid--20",
                        renderCell: this._renderNameItem,
                        sortable: false
                    },
                    oldValue: {
                        label: res.gridcommanddetail.column.currentversion,
                        className: "epi-grid--40",
                        renderCell: this._renderValueItem,
                        sortable: false
                    },
                    newValue: {
                        label: res.gridcommanddetail.column.suggestedversion,
                        className: "epi-grid--40",
                        renderCell: this._renderValueItem,
                        sortable: false
                    }
                },
                store: this.store
            }, this.defaultGridMixin);
        },

        _getGrid: function () {
            if (this._grid) {
                return this._grid;
            }

            return this._gridDefer;
        },

        _fetchData: function () {
            when(this._getGrid(), lang.hitch(this, function () {
                this._grid.set("queryOptions", { ignore: ["query"], sort: [{ attribute: "name", descending: false }] });
                this._grid.set("query", { commandId: this.commandId });
            }));
        },

        _setCommandIdAttr: function (commandId) {
            this.commandId = commandId;
            this._fetchData();
        },

        _renderNameItem: function (item, value, node) {
            node.innerText = value;
        },

        _renderValueItem: function (item, value, node) {
            formatters.contentItem(value, node);
        }
    });
});
