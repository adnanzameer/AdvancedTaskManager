define([
   "dojo",
   "dojo/when",
   "dojo/_base/declare",
   "dojo/_base/lang",
   "dojo/dom-class",
   "dojo/dom-style",
   "dojo/_base/array",

   "dijit/form/Button",

   "epi-cms/contentediting/ExpirationDialog",

   "epi-changeapproval/command/ViewChangeDetails",

   "epi/i18n!epi/nls/episerver.shared"
], function (
   dojo,
   when,
   declare,
   lang,
   domClass,
   domStyle,
   array,

   Button,

   ExpirationDialog,

   ViewChangeDetails,

   sharedResources
) {
    return declare([ExpirationDialog], {
        // summary:
        //      override epi-cms ExpirationDialog to set readOnly when there is an ongoing change approval
        // tags:
        //      internal

        postMixInProperties: function () {
            this.inherited(arguments);

            this._closeAction = {
                name: "close",
                label: sharedResources.action.close,
                settings: { type: "button" },
                action: lang.hitch(this, function () {
                    this.model.reset();
                    this.cancelDialog();
                })
            };
            this.modelBindingMap.isInReviewMode = ["isInReviewMode"];
            this.modelBindingMap.executeDialog = ["executeDialog"];
        },

        onChange: function () {
            if (this.model.hasApprovalCommandInReview()) {
                return;
            }

            this.inherited(arguments);
        },

        _createViewChangeDetailsLink: function () {
            var self = this;
            var command = new ViewChangeDetails();
            command.set("model", this.model.changeApprovalCommand);

            var button = new Button({
                    label: command.label,
                    iconClass: command.iconClass
            });

            if (command.cssClass) {
                domClass.add(button.domNode, command.cssClass);
            }

            button.set("disabled", !command.canExecute);

            button.on("click", function () {
                self.cancelDialog();
                command.execute();
            });

            this.own(command.watch("canExecute", lang.hitch(this, function () {
                button.set("disabled", !command.canExecute);
            })));

            this.own(button);

            button.placeAt(this.infoTextNode, "last");
        },

        getActions: function () {
            if (this.model.hasApprovalCommandInReview()) {
                this._actions = [this._closeAction];
                return this._actions;
            }

            this.inherited(arguments);
            this.hasAction("save") && this.setActionProperty("save", "action", lang.hitch(this, function () {
                if (this.validate()) {
                    this.model.save();
                }
            }));

            return this._actions;
        },

        _setEnableSaveButtonAttr: function (value) {
            if (this.hasAction("save")) {
                this.setActionProperty("save", "disabled", !value);
            }
        },

        _setIsInReviewModeAttr: function (value) {
            if (value) {
                this.set("readOnly", true);
                this.set("state", "");
                domClass.add(this.stateNode, "epi-changeapproval-statusIndicatorWarning");
                this._createViewChangeDetailsLink();
                var actionsToRemove = lang.clone(this._actions);
                this.removeActions(actionsToRemove);
                this.addActions([this._closeAction]);
            }
        },

        _setExecuteDialogAttr: function (value) {
            if (value) {
                this.executeDialog();
            }
        }
    });
});
