define([
    "dojo",
    "dojo/topic",
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/when",

    "epi/dependency",
    "epi-cms/contentediting/viewmodel/ExpirationDialogViewModel",
    "epi-cms/contentediting/ContentViewModel",
    "epi-cms/contentediting/ContentActionSupport",

    "epi-changeapproval/ModuleSettings",

    "epi/i18n!epi/cms/nls/episerver.changeapproval.interceptui"
], function (
    dojo,
    topic,
    declare,
    lang,
    when,

    dependency,
    ExpirationDialogViewModel,
    ContentViewModel,
    ContentActionSupport,

    ModuleSettings,

    res
) {
    return declare([ExpirationDialogViewModel, ContentViewModel], {

        // summary:
        //      override epi-cms ExpirationDialogViewModel to set readOnly when there is an ongoing change approval
        // tags:
        //      internal

        res: res,

        postscript: function () {

            this.inherited(arguments);

            this.changeApprovalService = this.changeApprovalService || dependency.resolve("epi-changeapproval.changeapprovalservice");

            when(this.changeApprovalService.getPendingApprovalCommand(this.contentLink), lang.hitch(this, function (approvalCommand) {
                this.changeApprovalCommand = approvalCommand;
                if (this.hasApprovalCommandInReview()) {
                    this._setInReviewMode();
                }
            }));
        },

        _setInReviewMode: function (message) {
            // summary:
            //      set readOnly mode and display warning message

            this.set("showRemoveButton", false);
            this.set("enableSaveButton", false);
            this.set("infoText", message || this._getApprovalInfoText());
            this.set("isInReviewMode", true);
        },

        hasApprovalCommandInReview: function () {
            // summary
            //      Check if there is an ongoing change approval command

            return !!this.changeApprovalCommand && this.changeApprovalCommand.status === ModuleSettings.approvalStatus.PENDING;
        },

        save: function () {
            // summary:
            //      Save the pending changes

            this.saveAndPublishProperty("iversionable_expire", this.intermediateValue, ContentActionSupport.saveAction.SkipValidation).then(lang.hitch(this, this.onSaved));
        },

        reset: function() {
            this.inherited(arguments);
            if (this.hasApprovalCommandInReview()) {
                this._setInReviewMode();
            }
        },

        onSaved: function() {
            when(this.changeApprovalService.getPendingApprovalCommand(this.contentLink), lang.hitch(this, function (approvalCommand) {
                this.changeApprovalCommand = approvalCommand;
                if (this.hasApprovalCommandInReview()) {
                    this._setInReviewMode(this.res.messagesentforreviewrequest);
                    topic.publish("/epi/cms/contentdata/updated", {
                        contentLink: this.contentLink,
                        recursive: true
                    });
                }
                else {
                    this.set("value", this.intermediateValue);
                    this.set("executeDialog", true);
                }
            }));
        },

        _getApprovalInfoText: function () {
            // summary
            //      get message when there is a ongoing change approval for the content

            var typeIdentifiers = this.changeApprovalCommand.typeIdentifier.split(".");
            var commandType = typeIdentifiers[typeIdentifiers.length - 1];

            if (commandType === "expirationdatesettingcommand") {
                return this.res.ongoingapprovalmessages.expirationdate;
            }

            return this.res.ongoingapprovalmessages.general;
        }
    });
});
