define([
// Dojo
    "dojo/_base/array",
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/dom-style",
    "dojo/dom-class",
    "dojo/when",

// Dijit
    "dijit/DropDownMenu",
    "dijit/_KeyNavContainer",
    "dijit/_WidgetsInTemplateMixin",

// EPi Framework
    "epi/shell/widget/_ModelBindingMixin",
    "epi/shell/command/builder/MenuBuilder",

// Resources
    "dojo/text!./templates/ApprovalMenu.html",
    "epi/i18n!epi/cms/nls/episerver.cms.contentediting.editactionpanel.publishactionmenu"
],

function (
// Dojo
    array,
    declare,
    lang,
    domStyle,
    domClass,
    when,

// Dijit
    DropDownMenu,
    _KeyNavContainer,
    _WidgetsInTemplateMixin,

// EPi Framework
    _ModelBindingMixin,
    MenuBuilder,

// Resources
    template
) {
    return declare([DropDownMenu, _WidgetsInTemplateMixin, _ModelBindingMixin], {
        // tags:
        //      internal

        templateString: template,

        // _menuBuilder: [private] Object
        //      Instance of menu builder
        _menuBuilder: null,

        // Binding properties
        commands: null,
        mainButtonCommand: null,

        postMixInProperties: function () {
            this._menuBuilder = new MenuBuilder();
        },

        // Binding map
        modelBindingMap: {
            commands: ["commands"],
            mainButtonCommand: ["mainButtonCommand"],
            mainButtonSectionVisible: ["mainButtonSectionVisible"],
            lastChangeStatus: ["lastChangeStatus"],
            topInfoSectionVisible: ["topInfoSectionVisible"],
            additionalInfoSectionVisible: ["additionalInfoSectionVisible"],
            additionalInfoText: ["additionalInfoText"],
            bottomInfoSectionVisible: ["bottomInfoSectionVisible"]
        },

        _setCommandsAttr: function (commands) {
            // Move focus away from current menu item, which may be removed after command executed.
            this.focusedChild = null;

            //Remove all children first
            this.destroyDescendants();

            this._addCommandsToMenu(commands);

            // Set focus on the main button or the first focusable item.
            this.focusFirstChild();
        },

        _setMainButtonCommandAttr: function (command) {
            this._set("mainButtonCommand", command);
            if (command) {
                this.mainButton.set("label", command.label);
                this.mainButton.set("disabled", !command.get("canExecute"));
                domClass.remove(this.mainButton.domNode, "epi-loading");

                if (this._addedMainButtonClass) {
                    domClass.remove(this.mainButton.domNode, this._addedMainButtonClass);
                }

                if (command.options && command.options.mainButtonClass) {
                    this._addedMainButtonClass = command.options.mainButtonClass;
                    domClass.add(this.mainButton.domNode, this._addedMainButtonClass);
                }
            }
        },

        _setMainButtonSectionVisibleAttr: function (visible) {
            domStyle.set(this.mainButtonSection, "display", visible ? "" : "none");

            // When hiding the main button section, we have to also hide the main button. Otherwise it is still focusable.
            domStyle.set(this.mainButton.domNode, "display", visible ? "" : "none");
        },

        _setLastChangeStatusAttr: {
            node: "lastChangeStatusNode",
            type: "innerHTML"
        },

        _setTopInfoSectionVisibleAttr: function (visible) {
            domStyle.set(this.topInfoSection, "display", visible ? "" : "none");
        },

        _setBottomInfoSectionVisibleAttr: function (visible) {
            domStyle.set(this.bottomInfoSection, "display", visible ? "" : "none");
        },

        _setAdditionalInfoSectionVisibleAttr: function (visible) {
            domStyle.set(this.additionalInfoSection, "display", visible ? "" : "none");
        },

        _setAdditionalInfoTextAttr: {
            node: "additionalInfoNode",
            type: "innerHTML"
        },

        postCreate: function () {
            this.inherited(arguments);

            // The main button should behave like a normal menu item.
            // When focused item is the main button and user close the menu, these functions which are not implemented in dijit/form/Button will be called.
            // So we supply dummy ones.
            this.mainButton._setSelected = this.mainButton._onUnhover = function () { };
        },

        onOpen: function () {
            this.model.set("isOpen", true);
            this.inherited(arguments);
        },

        onClose: function () {
            this.model.set("isOpen", false);
            this.inherited(arguments);
        },

        _setModelAttr: function () {
            this.inherited(arguments);

            this.ownByKey(this.model, this.connect(this.model, "onCommandsChanged", "onCommandsChanged"));
        },

        onCommandsChanged: function (name, removed, added) {
            // summary:
            //		Callback when available commands have been changed.
            // tags:
            //		public

            if (removed) {
                this._removeCommandsFromMenu(lang.isArray(removed) ? removed : [removed]);
            }
            if (added) {
                this._addCommandsToMenu(lang.isArray(added) ? added : [added]);
            }
        },

        _addCommandsToMenu: function (commands) {
            // summary:
            //		Transforms the commands into widgets and adds them to the toolbar.
            // tags:
            //		private

            array.forEach(commands, function (command) {
                if (command !== this.model.mainButtonCommand) {
                    this._menuBuilder.create(command, this);
                }
            }, this);
        },

        _removeCommandsFromMenu: function (commands) {
            // summary:
            //		Removes the commands from the toolbar.
            // tags:
            //		private

            var children = this.getChildren();

            array.forEach(commands, function (command) {
                for (var i = children.length - 1; i >= 0; i--) {
                    var item = children[i];
                    if (item._command === command) {
                        this.removeChild(item);
                        item.destroyRecursive();
                        break;
                    }
                }
            }, this);
        },

        _onMainButtonClick: function () {
            if (this.mainButtonCommand) {
                this.mainButton.set("label", this.mainButtonCommand.executingLabel);
                domClass.add(this.mainButton.domNode, "epi-loading");

                var lastExecutedCommand = this.mainButtonCommand,
                    resetMainButton = lang.hitch(this, function () {
                        if (lastExecutedCommand.options && lastExecutedCommand.options.resetLabelAfterExecution) {
                            this.mainButton.set("label", lastExecutedCommand.label);
                        }
                        domClass.remove(this.mainButton.domNode, "epi-loading");

                        if (lastExecutedCommand.options && !lastExecutedCommand.options.keepMenuOpen) {
                            this.onExecute();
                        }
                    }),
                    setLastExecutedCommand = lang.hitch(this, function () {
                        this.model.set("lastExecutedCommand", lastExecutedCommand);
                    });

                when(this.mainButtonCommand.execute(), function () {
                    return when(resetMainButton(), setLastExecutedCommand);
                }, function () {
                    return resetMainButton();
                });
            }
        },

        focusFirstChild: function () {
            // summary:
            //		Focus the first focusable child in the container.
            // tags:
            //		protected

            if (this.mainButton.isFocusable()) {
                return this.focusChild(this.mainButton);
            } else {
                return this.inherited(arguments);
            }
        }
    });
});
