﻿define([
// dojo
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/topic",
    "dojo/when",
    "dojo/aspect",

// epi-cms
    "epi-cms/widget/_GridWidgetBase"



],
function (
// dojo
    declare,
    lang,
    topic,
    when,
    aspect,

// epi-cms
    _GridWidgetBase


) {

    // module:
    //      epi-changeapproval/changeapprovalmodule
    // summary:
    //      EPiServer ChangeApproval main.
    // tags:
    //      public

    return declare([_GridWidgetBase], {
        // summary: This component will list the latest changed pages for the web site.
        //
        // tags:
        //      internal

        // queryName: string
        //    The name of the content query used to fetch data for the grid.
        queryName: null,

        queryParameters: null,

        dndTypes: ["epi.cms.contentreference"],

        trackActiveItem: false,

        postMixInProperties: function () {
            // summary:
            //
            // tags:
            //    protected

            this.storeKeyName = "epi-changeapproval.commanddata";
            this.inherited(arguments);
        },

        buildRendering: function () {
            // summary:
            //		Construct the UI for this widget with this.domNode initialized as a dgrid.
            // tags:
            //		protected

            this.inherited(arguments);

            var gridSettings = lang.mixin({
                columns: {
                    name: {
                        renderCell: lang.hitch(this, this._renderContentItem)
                    }
                },
                store: this.store,
                dndSourceType: this.dndTypes
            }, this.defaultGridMixin);

            this.grid = new this._gridClass(gridSettings, this.domNode);

            this.grid.set("showHeader", false);

            this.own(
                aspect.around(this.grid, "insertRow", lang.hitch(this, this._aroundInsertRow))
            );
        },
          
        fetchData: function () {

            when(this._getCurrentItem(), lang.hitch(this, function (currentItem) {
                this.set("currentItem", currentItem);
            }));

            var queryParameters = this.queryParameters || {};
            queryParameters.query = this.queryName;
            this.grid.set("query", queryParameters);
        },

        _setQueryNameAttr: function (value) {
            this.queryName = value;
            this.fetchData();
        },

        _renderContentItem: function (object, value, node) {
            node.innerHTML = value;
        }
    });

});